public class Main {
    public static void main(String[] args) {
        for (int i = 0; i <= 18; i += 3)
        { System.out.print(i + " ");}
    }
}